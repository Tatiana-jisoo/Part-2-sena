from django.db import models

class Grupo(models.Model):
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre

class Aprendiz(models.Model):
    nombre = models.CharField(max_length=100)

class Curso(models.Model):
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre

class Centro(models.Model):
    nombre = models.CharField(max_length=100)
    ciudad = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre

class Red(models.Model):
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre