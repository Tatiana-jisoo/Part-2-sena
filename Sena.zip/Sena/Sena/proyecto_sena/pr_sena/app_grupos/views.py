from django.shortcuts import render
from django.http import HttpResponse
from django.views import View
from django.views.generic import ListView
from .models import Curso, Centro, Red

def cargar_datos(request):
    Curso.objects.get_or_create(nombre='Análisis y Desarrollo de Software')
    Curso.objects.get_or_create(nombre='Gestión de Redes de Datos')
    Curso.objects.get_or_create(nombre='Multimedia')

    Centro.objects.get_or_create(nombre='Centro de Servicios Financieros', ciudad='Bogotá')
    Centro.objects.get_or_create(nombre='Centro de Electricidad', ciudad='Cali')
    Centro.objects.get_or_create(nombre='Centro de Diseño', ciudad='Medellín')

    Red.objects.get_or_create(nombre='Red TIC')
    Red.objects.get_or_create(nombre='Red de Logística')
    Red.objects.get_or_create(nombre='Red de Administración')

    return HttpResponse("¡Datos cargados correctamente!")

def cursos_fbv(request):
    cursos = Curso.objects.all()
    return render(request, 'app_grupos/cursos.html', {'cursos': cursos})

class CentrosCBV(View):
    def get(self, request):
        centros = Centro.objects.all()
        return render(request, 'app_grupos/centros.html', {'centros': centros})

class RedesListView(ListView):
    model = Red
    template_name = 'app_grupos/redes.html'
    context_object_name = 'redes'

def inicio_sena(request):
    return render(request, 'app_grupos/inicio.html')