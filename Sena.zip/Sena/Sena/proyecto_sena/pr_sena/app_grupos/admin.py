from django.contrib import admin
from .models import Aprendiz, Grupo, Curso, Centro, Red

admin.site.register(Aprendiz)
admin.site.register(Grupo)
admin.site.register(Curso)
admin.site.register(Centro)
admin.site.register(Red)