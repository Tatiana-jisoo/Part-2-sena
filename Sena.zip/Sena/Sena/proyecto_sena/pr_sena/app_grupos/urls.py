from django.urls import path
from . import views

urlpatterns = [
    path('', views.inicio_sena, name='inicio'),
    path('cargar_datos/', views.cargar_datos, name='cargar_datos'),
    path('cursos_fbv/', views.cursos_fbv, name='cursos_fbv'),
    path('centros/cbv/', views.CentrosCBV.as_view(), name='centros_cbv'),
    path('redes/gcbv/', views.RedesListView.as_view(), name='redes_gcbv'),
]